<!DOCTYPE html>
<html data-bs-theme="light" lang="en-US" dir="ltr">

<head>
    
    <?php echo $__env->make('layouts.partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <title><?php echo $__env->yieldContent('title', 'Login'); ?> | OCEI</title>
</head>

<body>

<!-- Main Content Wrapper for Guest Pages -->
<main class="main" id="top">
    <div class="container-fluid">
        
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</main>


<?php echo $__env->make('layouts.partials.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html>
<?php /**PATH /var/www/html/resources/views/layouts/partials/guest.blade.php ENDPATH**/ ?>