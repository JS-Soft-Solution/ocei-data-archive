<?php $__env->startSection('title', 'Account Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row min-vh-100 flex-center g-0">
        <div class="col-lg-8 col-xxl-5 py-3 position-relative">
            <img class="bg-auth-circle-shape" src="<?php echo e(asset('assets/img/icons/spot-illustrations/bg-shape.png')); ?>" alt="" width="250">
            <img class="bg-auth-circle-shape-2" src="<?php echo e(asset('assets/img/icons/spot-illustrations/shape-1.png')); ?>" alt="" width="150">

            <div class="card overflow-hidden z-1">
                <div class="card-body p-0">
                    <div class="row g-0 h-100">
                        
                        <div class="col-md-5 text-center bg-card-gradient">
                            <div class="position-relative p-4 pt-md-5 pb-md-7" data-bs-theme="light">
                                <div class="bg-holder bg-auth-card-shape" style="background-image:url(<?php echo e(asset('assets/img/icons/spot-illustrations/half-circle.png')); ?>);"></div>
                                <div class="z-1 position-relative">
                                    <a class="link-light mb-4 font-sans-serif fs-5 d-inline-block fw-bolder bg-white rounded p-2" href="<?php echo e(url('/')); ?>">
                                        <img src="<?php echo e(asset('assets/img/ocei-logo.png')); ?>" alt="OCEI Logo" class="img-fluid" style="max-width: 200px;">
                                    </a>
                                    <p class="opacity-75 text-white">OCEI Data Archive Solution. <br>Restricted Access Only.</p>
                                </div>
                            </div>
                        </div>

                        
                        <div class="col-md-7 d-flex flex-center">
                            <div class="p-4 p-md-5 flex-grow-1">
                                <div class="row flex-between-center">
                                    <div class="col-auto">
                                        <h3>Account Login</h3>
                                    </div>
                                </div>

                                <form method="POST" action="<?php echo e(route('login.perform')); ?>">
                                    <?php echo csrf_field(); ?>

                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger border-0 fs-10 p-2 mb-3">
                                            <ul class="mb-0 ps-3">
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success border-0 fs-10 p-2 mb-3">
                                            <?php echo e(session('success')); ?>

                                        </div>
                                    <?php endif; ?>

                                    <div class="mb-3">
                                        <label class="form-label" for="login_id">Email or User ID</label>
                                        <input class="form-control" id="login_id" name="login_id" type="text" value="<?php echo e(old('login_id')); ?>" required autofocus />
                                    </div>

                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between">
                                            <label class="form-label" for="password">Password</label>
                                        </div>
                                        <input class="form-control" id="password" name="password" type="password" required />
                                    </div>

                                    <div class="row flex-between-center">
                                        <div class="col-auto">
                                            <div class="form-check mb-0">
                                                <input class="form-check-input" type="checkbox" id="card-checkbox" name="remember" />
                                                <label class="form-check-label mb-0" for="card-checkbox">Remember me</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-auto">
                                            <a class="fs-10" href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <button class="btn btn-primary d-block w-100 mt-3" type="submit">Log in</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/auth/login.blade.php ENDPATH**/ ?>