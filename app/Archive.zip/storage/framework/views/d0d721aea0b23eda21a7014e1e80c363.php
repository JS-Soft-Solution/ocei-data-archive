<?php $__env->startSection('title', 'Edit User - ' . $user->full_name); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card theme-wizard mb-5">
                <div class="card-header bg-body-tertiary pt-3 pb-2">
                    <ul class="nav justify-content-between nav-wizard">
                        <li class="nav-item"><a class="nav-link active fw-semi-bold" href="#bootstrap-wizard-tab1" data-bs-toggle="tab" data-wizard-step="1"><span class="nav-item-circle-parent"><span class="nav-item-circle"><span class="fas fa-lock"></span></span></span><span class="d-none d-md-block mt-1 fs-10">Account</span></a></li>
                        <li class="nav-item"><a class="nav-link fw-semi-bold" href="#bootstrap-wizard-tab2" data-bs-toggle="tab" data-wizard-step="2"><span class="nav-item-circle-parent"><span class="nav-item-circle"><span class="fas fa-user"></span></span></span><span class="d-none d-md-block mt-1 fs-10">Personal</span></a></li>
                        <li class="nav-item"><a class="nav-link fw-semi-bold" href="#bootstrap-wizard-tab3" data-bs-toggle="tab" data-wizard-step="3"><span class="nav-item-circle-parent"><span class="nav-item-circle"><span class="fas fa-map-marker-alt"></span></span></span><span class="d-none d-md-block mt-1 fs-10">Address</span></a></li>
                        <li class="nav-item"><a class="nav-link fw-semi-bold" href="#bootstrap-wizard-tab4" data-bs-toggle="tab" data-wizard-step="4"><span class="nav-item-circle-parent"><span class="nav-item-circle"><span class="fas fa-thumbs-up"></span></span></span><span class="d-none d-md-block mt-1 fs-10">Done</span></a></li>
                    </ul>
                </div>

                
                <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?> 

                    <div class="card-body py-4">
                        <div class="tab-content">

                            
                            <div class="tab-pane active px-sm-3 px-md-5" role="tabpanel" aria-labelledby="bootstrap-wizard-tab1" id="bootstrap-wizard-tab1">

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">User ID (Auto-generated)</label>
                                        <input class="form-control" type="text" value="<?php echo e($user->user_id); ?>" disabled readonly />
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Role / Designation</label>
                                        <select class="form-select <?php $__errorArgs = ['admin_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="admin_type" required>
                                            <option value="">Select Role...</option>
                                            <?php $__currentLoopData = ['super_admin', 'secretary', 'chairman', 'office_assistant', 'data_entry_operator']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role); ?>" <?php echo e(old('admin_type', $user->admin_type) == $role ? 'selected' : ''); ?>>
                                                    <?php echo e(ucwords(str_replace('_', ' ', $role))); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['admin_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Full Name</label>
                                    <input class="form-control <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="full_name" value="<?php echo e(old('full_name', $user->full_name)); ?>" required />
                                    <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Email</label>
                                    <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required />
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Mobile No</label>
                                    <input class="form-control <?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="mobile_no" value="<?php echo e(old('mobile_no', $user->mobile_no)); ?>" required />
                                    <?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="alert alert-info fs-10 p-2 mb-3" role="alert">
                                    <span class="fas fa-info-circle me-2"></span>Leave password fields blank if you do not want to change it.
                                </div>

                                <div class="row gx-2">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">New Password</label>
                                            <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password" placeholder="Min 8 characters" />
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Confirm New Password</label>
                                            <input class="form-control" type="password" name="password_confirmation" placeholder="Confirm Password" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="tab-pane px-sm-3 px-md-5" role="tabpanel" aria-labelledby="bootstrap-wizard-tab2" id="bootstrap-wizard-tab2">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Father's Name</label>
                                        <input class="form-control" type="text" name="father_name" value="<?php echo e(old('father_name', $user->father_name)); ?>" />
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Mother's Name</label>
                                        <input class="form-control" type="text" name="mother_name" value="<?php echo e(old('mother_name', $user->mother_name)); ?>" />
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">NID Number</label>
                                    <input class="form-control" type="text" name="nid_no" value="<?php echo e(old('nid_no', $user->nid_no)); ?>" />
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Date of Birth</label>
                                        
                                        <input class="form-control datetimepicker" type="text" name="dob" placeholder="Y-m-d" value="<?php echo e(old('dob', $user->dob ? $user->dob->format('Y-m-d') : '')); ?>" data-options='{"dateFormat":"Y-m-d","disableMobile":true}' />
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Gender</label>
                                        <select class="form-select" name="gender">
                                            <option value="">Select...</option>
                                            <option value="Male" <?php echo e(old('gender', $user->gender) == 'Male' ? 'selected' : ''); ?>>Male</option>
                                            <option value="Female" <?php echo e(old('gender', $user->gender) == 'Female' ? 'selected' : ''); ?>>Female</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="tab-pane px-sm-3 px-md-5" role="tabpanel" aria-labelledby="bootstrap-wizard-tab3" id="bootstrap-wizard-tab3">
                                <h5 class="mb-3">Present Address</h5>
                                <div class="row g-2">
                                    <div class="col-md-6 mb-3"><label class="form-label">District</label><input class="form-control" type="text" name="pre_district" value="<?php echo e(old('pre_district', $user->pre_district)); ?>" /></div>
                                    <div class="col-md-6 mb-3"><label class="form-label">Upazila</label><input class="form-control" type="text" name="pre_upozila" value="<?php echo e(old('pre_upozila', $user->pre_upozila)); ?>" /></div>
                                    <div class="col-12 mb-3"><label class="form-label">Village/Road</label><input class="form-control" type="text" name="pre_village" value="<?php echo e(old('pre_village', $user->pre_village)); ?>" /></div>
                                </div>

                                <hr class="my-4">

                                <h5 class="mb-3">Permanent Address</h5>
                                <div class="row g-2">
                                    <div class="col-md-6 mb-3"><label class="form-label">District</label><input class="form-control" type="text" name="per_district" value="<?php echo e(old('per_district', $user->per_district)); ?>" /></div>
                                    <div class="col-md-6 mb-3"><label class="form-label">Upazila</label><input class="form-control" type="text" name="per_upozila" value="<?php echo e(old('per_upozila', $user->per_upozila)); ?>" /></div>
                                    <div class="col-12 mb-3"><label class="form-label">Village/Road</label><input class="form-control" type="text" name="per_village" value="<?php echo e(old('per_village', $user->per_village)); ?>" /></div>
                                </div>
                            </div>

                            
                            <div class="tab-pane text-center px-sm-3 px-md-5" role="tabpanel" aria-labelledby="bootstrap-wizard-tab4" id="bootstrap-wizard-tab4">

                                
                                <div class="mb-4 d-flex justify-content-center flex-column align-items-center">
                                    <label class="form-label">Current Profile Image</label>
                                    <div class="avatar avatar-4xl mb-2">
                                        <?php if($user->applicant_image): ?>
                                            <img class="rounded-circle img-thumbnail" src="<?php echo e(asset('storage/'.$user->applicant_image)); ?>" alt="Profile" />
                                        <?php else: ?>
                                            <div class="avatar-name rounded-circle"><span><?php echo e(substr($user->full_name, 0, 2)); ?></span></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Change Image (Optional)</label>
                                    <input class="form-control" type="file" name="applicant_image" accept="image/*" />
                                    <div class="form-text">Upload to replace the current image. Max 2MB.</div>
                                </div>

                                <hr class="my-4" />

                                <h4 class="mb-1">Ready to Update?</h4>
                                <p>Please review your changes before saving.</p>

                                <button class="btn btn-primary px-5 my-3" type="submit">Update User Information</button>
                            </div>
                        </div>
                    </div>

                    
                    <div class="card-footer bg-body-tertiary">
                        <div class="px-sm-3 px-md-5">
                            <ul class="pager wizard list-inline mb-0">
                                <li class="previous"><button class="btn btn-link ps-0" type="button"><span class="fas fa-chevron-left me-2" data-fa-transform="shrink-3"></span>Prev</button></li>
                                <li class="next"><button class="btn btn-primary px-5 px-sm-6" type="button">Next<span class="fas fa-chevron-right ms-2" data-fa-transform="shrink-3"> </span></button></li>
                            </ul>
                        </div>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/users/edit.blade.php ENDPATH**/ ?>