<!-- ===============================================-->
<!--    JavaScripts-->
<!-- ===============================================-->
<script src="<?php echo e(asset('vendors/popper/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/bootstrap/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/anchorjs/anchor.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/is/is.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/echarts/echarts.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/fontawesome/all.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/lodash/lodash.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/list.js/list.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/theme.js')); ?>"></script>
<?php /**PATH /var/www/html/resources/views/layouts/partials/scripts.blade.php ENDPATH**/ ?>